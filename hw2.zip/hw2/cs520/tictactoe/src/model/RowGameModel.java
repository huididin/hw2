package model;


public class RowGameModel 
{
    public static final String GAME_END_NOWINNER = "Game ends in a draw";

    public RowBlockModel[][] blocksData = new RowBlockModel[3][3];
    /**
     * The current player taking their turn
     */
    private Player player = Player.PLAYER_0;
    public int movesLeft = 9;

    private String finalResult = null;




    public RowGameModel() {
	super();

	for (int row = 0; row < 3; row++) {
	    for (int col = 0; col < 3; col++) {
		blocksData[row][col] = new RowBlockModel(this);
	    } // end for col
	} // end for row
    }

    public enum Player {
        PLAYER_0(1), PLAYER_1(2);
        // Here is an example implementation of the modified setPlayer method using an enumerated type:
        // This will help to ensure type safety and avoid potential bugs that can arise from using string literals.
        public static final String label = "PLAYER";

        private int num;

        private Player(int num){
            this.num = num;
        }
        private String getLabel(){
            return label + this.num;
        }



    }
    public Player getPlayer(){
        return this.player;
    }



    public void setPlayer(Player player){
        if (player != null || player.equals("1") || player.equals("2")) {
            this.player = player;
        } else {
            throw new IllegalArgumentException("Player cannot be null or other than 1 or 2.");
        }
    }


    public int getMovesLeft(){
        return this.movesLeft;
    }

    public void setMovesLeft(){
        this.movesLeft = movesLeft;
    }


    public String getFinalResult() {
	return this.finalResult;
    }

    public void setFinalResult(String finalResult) {
	this.finalResult = finalResult;
    }
}

