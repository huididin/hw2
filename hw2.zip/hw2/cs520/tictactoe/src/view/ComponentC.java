package view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;

import model.RowGameModel.Player;
import model.RowGameModel;
import controller.RowGameController;
import view.View;



public class ComponentC implements View
{
    public JTextArea playerturn = new JTextArea();

    public ComponentC(JPanel messages){
        messages.add(playerturn);
        playerturn.setText("Player 1 to play 'X'");
        playerturn.setEditable(false);
    }


    public boolean isDouble(int a){
        if(a % 2 != 1){
            return true;
        }
        return false;
    }
    public void update(RowGameModel model) {
        if(model.getFinalResult() != null){
            playerturn.setText(model.getFinalResult());
        }else{
            if(isDouble(model.getMovesLeft())){
                playerturn.setText("'O':" + RowGameModel.Player.PLAYER_1);
            }else{
                playerturn.setText("'O':" + RowGameModel.Player.PLAYER_0);
            }
        }
    }
}