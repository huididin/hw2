#!/bin/sh

MAJOR_HOME="lib/major"

$MAJOR_HOME/bin/ant test
